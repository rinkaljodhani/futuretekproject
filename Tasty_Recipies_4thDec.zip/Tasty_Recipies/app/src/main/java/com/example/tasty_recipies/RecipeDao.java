package com.example.tasty_recipies;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;

@Dao
public interface RecipeDao {

    @Insert
    void addNewFavRecipe(Receipes receipes);

    @Query("select * from Receipes")
    Receipes[] getAllReceipes();

    @Delete
    void deleteFavRecipe(Receipes dc);
}
