package com.example.tasty_recipies.activity;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.Manifest;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.example.tasty_recipies.DBManager;
import com.example.tasty_recipies.JsonService;
import com.example.tasty_recipies.MyApp;
import com.example.tasty_recipies.NetworkingService;
import com.example.tasty_recipies.R;
import com.example.tasty_recipies.Receipes;
import com.example.tasty_recipies.adapter.RecipiesListAdapter;
import com.tuyenmonkey.mkloader.MKLoader;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements NetworkingService.NetworkingListener, View.OnClickListener, DBManager.DataBaseListener {


    RecyclerView rv_list;
    RecipiesListAdapter adapter;
    ArrayList<Receipes> list = new ArrayList<>(0);
    TextView tv_favlist;
    LinearLayout ll_layout;
    MKLoader mkloader;
    private static final int PERMISSION_REQUEST_CODE = 1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            checkPermissions();
        }

        ((MyApp) getApplication()).networkingService.listener = this;
        findView();

        ConnectivityManager connectivityManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);

        boolean connected = (connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE).getState() == NetworkInfo.State.CONNECTED ||
                connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_WIFI).getState() == NetworkInfo.State.CONNECTED);

        if (connected) {
            ((MyApp) getApplication()).networkingService.getRecipieDetails();
        }else{
            Toast.makeText(MainActivity.this, getString(R.string.str_internet_check),Toast.LENGTH_LONG).show();
        }


    }

    @RequiresApi(api = Build.VERSION_CODES.M)
    private void checkPermissions() {
        // Check if the READ_EXTERNAL_STORAGE permission is not granted
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED ||
                // Check if the WRITE_EXTERNAL_STORAGE permission is not granted
                ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE)
                        != PackageManager.PERMISSION_GRANTED) {

            // Request permissions
            ActivityCompat.requestPermissions(
                    this,
                    new String[]{
                            Manifest.permission.READ_EXTERNAL_STORAGE,
                            Manifest.permission.WRITE_EXTERNAL_STORAGE
                    },
                    PERMISSION_REQUEST_CODE
            );
        }
    }

    @Override
    public void onRequestPermissionsResult(
            int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == PERMISSION_REQUEST_CODE) {
            // Check if all permissions are granted
            if (grantResults.length > 0 &&
                    grantResults[0] == PackageManager.PERMISSION_GRANTED &&
                    grantResults[1] == PackageManager.PERMISSION_GRANTED) {
                // Permissions are granted, you can now perform read and write operations
            } else {
                // Permissions are denied
                // Handle this case, show a message, or disable functionality that requires permissions
            }
        }
    }

    private void findView() {

        rv_list = findViewById(R.id.rv_list);
        mkloader = findViewById(R.id.mkloader);
        ll_layout = findViewById(R.id.ll_layout);
        tv_favlist = findViewById(R.id.tv_favlist);
        adapter = new RecipiesListAdapter(this, list, false);
        rv_list.setAdapter(adapter);
        rv_list.setLayoutManager(new LinearLayoutManager(this));
        ((MyApp) getApplication()).dbManager.listener = this;

        ((MyApp) getApplication()).dbManager.getDB(this);
        tv_favlist.setOnClickListener(this);
    }

    @Override
    public void gettingJsonIsCompleted(String json) {
        mkloader.setVisibility(View.GONE);
        ll_layout.setVisibility(View.VISIBLE);
        list = JsonService.fromJSONToList(json);
        adapter.list = list;
        adapter.notifyDataSetChanged();
    }

    @Override
    public void gettingImageIsCompleted(Bitmap image) {

    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.tv_favlist:
                startActivity(new Intent(MainActivity.this, FavouriteActivity.class));
                break;
        }
    }

    @Override
    public void insertingRecipeCompleted() {
        Toast.makeText(MainActivity.this, "Recipe is successfully added to Favourite list", Toast.LENGTH_LONG).show();

    }

    @Override
    public void deleteRecipeCompleted() {
        Toast.makeText(MainActivity.this, "Recipe is successfully removed from Favourite list", Toast.LENGTH_LONG).show();
    }

    @Override
    public void gettingRecipesCompleted(Receipes[] list) {

    }

    @Override
    public void alreadyinsertingRecipeCompleted() {
        Toast.makeText(MainActivity.this, "Already added", Toast.LENGTH_LONG).show();

    }

    @Override
    public void onBackPressed() {
        new AlertDialog.Builder(this)
                .setMessage("Are you sure you want to exit from app?")
                .setPositiveButton("Yes", new DialogInterface.OnClickListener()
                {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        finish();
                    }

                })
                .setNegativeButton("No", null)
                .show();
    }
}