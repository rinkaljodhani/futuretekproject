package com.example.tasty_recipies.activity;

import static android.widget.FrameLayout.*;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.app.DownloadManager;
import android.content.DialogInterface;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.os.StrictMode;
import android.util.Log;
import android.view.View;
import android.widget.MediaController;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.VideoView;

import com.example.tasty_recipies.DBManager;
import com.example.tasty_recipies.MyApp;
import com.example.tasty_recipies.R;
import com.example.tasty_recipies.Receipes;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class RecipeDetailsActivity extends AppCompatActivity implements View.OnClickListener, DBManager.DataBaseListener {

    Receipes receipes;
    TextView tv_des, tv_save, tv_delete, tv_share;
    VideoView video_view;

    boolean flag1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recipe_details);

        StrictMode.VmPolicy.Builder builder = new StrictMode.VmPolicy.Builder();
        StrictMode.setVmPolicy(builder.build());

        findView();

    }

    private void findView() {

        receipes = (Receipes) getIntent().getSerializableExtra("response");
        flag1 = getIntent().getBooleanExtra("flag", false);

        getSupportActionBar().setTitle(receipes.name);

        tv_des = findViewById(R.id.tv_des);
        tv_save = findViewById(R.id.tv_save);
        tv_delete = findViewById(R.id.tv_delete);
        tv_share = findViewById(R.id.tv_share);
        video_view = findViewById(R.id.video_view);

        Uri uri = Uri.parse(receipes.video_url);
        video_view.setVideoURI(uri);

        if (flag1) {
            tv_save.setVisibility(GONE);
            tv_delete.setVisibility(VISIBLE);
        } else {
            tv_save.setVisibility(VISIBLE);
            tv_delete.setVisibility(GONE);
        }

        MediaController mediaController = new MediaController(this);
        mediaController.setAnchorView(video_view);
        mediaController.setMediaPlayer(video_view);
        video_view.setMediaController(mediaController);
        video_view.start();


        tv_des.setText(receipes.des);
        tv_save.setOnClickListener(this);
        tv_delete.setOnClickListener(this);
        tv_share.setOnClickListener(this);


    }

    @Override
    public void onClick(View v) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);

        switch (v.getId()) {
            case R.id.tv_save:
                builder.setMessage("Are you sure you want to save " + receipes.name + " to the DB??");
                builder.setNegativeButton("No", null);
                builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {

                        ((MyApp) getApplication()).dbManager.insertreceipe(receipes);
                    }
                });
                builder.create().show();
                break;
            case R.id.tv_delete:
                builder.setMessage("Are you sure you want to delete " + receipes.name + " to the DB??");
                builder.setNegativeButton("No", null);
                builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {

                        ((MyApp) getApplication()).dbManager.deleterecipe(receipes);
                        finish();
                    }
                });
                builder.create().show();
                break;
            case R.id.tv_share:
                new DownloadHlsTask().execute(receipes.video_url);
                break;
        }
    }

    private class DownloadHlsTask extends AsyncTask<String, Void, Void> {

        @Override
        protected Void doInBackground(String... params) {
            String hlsUrl = params[0];

            try {
                List<String> segmentUrls = parseHlsPlaylist(hlsUrl);

                for (String segmentUrl : segmentUrls) {
                    downloadSegment(segmentUrl);
                }

                Log.d("DownloadVideoActivity", "Download complete");

            } catch (Exception e) {
                e.printStackTrace();
                Log.e("DownloadVideoActivity", "Download failed: " + e.getMessage());
            }

            return null;
        }
    }

    private List<String> parseHlsPlaylist(String hlsUrl) throws IOException {
        List<String> segmentUrls = new ArrayList<>();

        OkHttpClient client = new OkHttpClient();
        Request request = new Request.Builder().url(hlsUrl).build();
        Response response = client.newCall(request).execute();

        if (!response.isSuccessful()) {
            throw new IOException("Unexpected code " + response);
        }

        try (BufferedReader reader = new BufferedReader(new InputStreamReader(response.body().byteStream()))) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (line.endsWith(".ts")) { // Adjust based on your HLS playlist structure
                    segmentUrls.add(line);
                }
            }
        }

        return segmentUrls;
    }

    private void downloadSegment(String segmentUrl) {
        try {
            OkHttpClient client = new OkHttpClient();
            Request request = new Request.Builder().url(segmentUrl).build();
            Response response = client.newCall(request).execute();

            if (!response.isSuccessful()) {
                throw new IOException("Unexpected code " + response);
            }

            saveSegment(response.body().bytes());

        } catch (IOException e) {
            e.printStackTrace();
            Log.e("DownloadVideoActivity", "Download segment failed: " + e.getMessage());
        }
    }

    private void saveSegment(byte[] data) {
        try {
            File directory = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "YourAppFolder");
            if (!directory.exists()) {
                directory.mkdirs();
            }

            File file = new File(directory, "downloaded_video.ts"); // Use the appropriate extension

            try (FileOutputStream fos = new FileOutputStream(file, true)) {
                fos.write(data);
            }

        } catch (IOException e) {
            e.printStackTrace();
            Log.e("DownloadVideoActivity", "Save segment failed: " + e.getMessage());
        }
    }

    @Override
    public void insertingRecipeCompleted() {
        Toast.makeText(RecipeDetailsActivity.this, "Recipe is successfully added to Favourite list", Toast.LENGTH_LONG).show();

    }

    @Override
    public void deleteRecipeCompleted() {
        Toast.makeText(RecipeDetailsActivity.this, "Recipe is successfully removed from Favourite list", Toast.LENGTH_LONG).show();
    }

    @Override
    public void gettingRecipesCompleted(Receipes[] list) {

    }

    @Override
    public void alreadyinsertingRecipeCompleted() {
        Log.e("alreadyinserting::", "ttt");
        Toast.makeText(RecipeDetailsActivity.this, "Already added", Toast.LENGTH_LONG).show();

    }
}
