package com.example.tasty_recipies;

import android.os.Parcel;
import android.os.Parcelable;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

import java.io.Serializable;

@Entity
public class Receipes implements Parcelable, Serializable {

    @PrimaryKey(autoGenerate = true)
    public int id;
    public String name;
    public String des;
    public String thumbnail_url;
    public String video_url;

    public Receipes(String name, String des, String thumbnail_url, String video_url) {
        this.name = name;
        this.des = des;
        this.thumbnail_url = thumbnail_url;
        this.video_url = video_url;
    }

    protected Receipes(Parcel in) {
        id = in.readInt();
        name = in.readString();
        des = in.readString();
        thumbnail_url = in.readString();
        video_url = in.readString();
    }

    public static final Creator<Receipes> CREATOR = new Creator<Receipes>() {
        @Override
        public Receipes createFromParcel(Parcel in) {
            return new Receipes(in);
        }

        @Override
        public Receipes[] newArray(int size) {
            return new Receipes[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(id);
        dest.writeString(name);
        dest.writeString(des);
        dest.writeString(thumbnail_url);
        dest.writeString(video_url);
    }
}
