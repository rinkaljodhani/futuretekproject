package com.example.tasty_recipies.adapter;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.StrictMode;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.example.tasty_recipies.R;
import com.example.tasty_recipies.Receipes;
import com.example.tasty_recipies.activity.RecipeDetailsActivity;

import java.io.IOException;
import java.io.InputStream;
import java.io.Serializable;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;

public class RecipiesListAdapter extends
        RecyclerView.Adapter<RecipiesListAdapter.ReceipeViewHolder>{

    Context context;
    public ArrayList<Receipes> list;
    boolean flag;

    public RecipiesListAdapter(Context context, ArrayList<Receipes> list,boolean flag) {
        this.context = context;
        this.list = list;
        this.flag = flag;
    }

    @NonNull
    @Override
    public ReceipeViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(context).inflate(R.layout.receipe_row,parent,false);
        return new ReceipeViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull ReceipeViewHolder holder, int position) {
        holder.tv_name.setText(list.get(position).name);
        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder()
                .permitAll().build();
        StrictMode.setThreadPolicy(policy);
        URL url = null;
        try {
            url = new URL(list.get(position).thumbnail_url);
            InputStream in = url.openStream();//new BufferedInputStream(urlConnection.getInputStream());
            Bitmap imageData = BitmapFactory.decodeStream(in);
            holder.iv_image.setImageBitmap(imageData);
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        holder.card_layout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, RecipeDetailsActivity.class);
                intent.putExtra("response", (Serializable) list.get(position));
                intent.putExtra("flag", flag);
                context.startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    // inner class
    public class ReceipeViewHolder extends RecyclerView.ViewHolder

    {
        ImageView iv_image;
        TextView tv_name;
        CardView card_layout;

        public ReceipeViewHolder(@NonNull View itemView) {
            super(itemView);
            iv_image =  itemView.findViewById(R.id.iv_image);
            tv_name =  itemView.findViewById(R.id.tv_name);
            card_layout =  itemView.findViewById(R.id.card_layout);
        }


    }
}
