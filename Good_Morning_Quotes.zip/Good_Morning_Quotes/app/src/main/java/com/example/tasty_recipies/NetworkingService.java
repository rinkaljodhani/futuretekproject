package com.example.tasty_recipies;

import android.graphics.Bitmap;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

public class NetworkingService {
    // fetch all cities
    // fetch weather in one city

    public interface NetworkingListener {
        void gettingJsonIsCompleted(String json);

        void gettingImageIsCompleted(Bitmap image);
    }


    public NetworkingListener listener;
    Handler handler = new Handler(Looper.getMainLooper());

    String url = "https://gujjumemehub.yellowsparrowtechnologies.com/GoodMorning/GmCategory";
    String url_cat = "https://gujjumemehub.yellowsparrowtechnologies.com/GoodMorning/GmImageAndQuote?CategoryId=";

    public void getRecipieDetails() {
        connect(false,0, url);
    }

    public void getQuoteList(int id) {
        connect(true,id,url_cat);
    }

    void connect(Boolean flag,int id, String urlString) {
        MyApp.executorService.execute(new Runnable() {
            @Override
            public void run() {
                HttpURLConnection urlConnection = null;
                try {
                    URL url;
                    int value = 0;
                    if(flag){
                        url = new URL(urlString+id);

                    }else {
                        url = new URL(urlString);
                    }
                    urlConnection = (HttpURLConnection) url.openConnection();
//                    urlConnection.setRequestProperty("X-RapidAPI-Key", "bc62e6226amsh885dc10a1d116f6p1ada70jsna779ddc725ba");
//                    urlConnection.setRequestProperty("X-RapidAPI-Host", "tasty.p.rapidapi.com");
                    InputStream in = new BufferedInputStream(urlConnection.getInputStream());
                    StringBuffer buffer = new StringBuffer();
                    while ((value = in.read()) != -1) {
                        buffer.append((char) value);
                    }
                    // the json content is ready to returned back
                    handler.post(new Runnable() {
                        @Override
                        public void run() {
                            Log.e( "run::::: ",buffer.toString() );
                            listener.gettingJsonIsCompleted(buffer.toString());
                        }
                    });
                } catch (MalformedURLException e) {
                    e.printStackTrace();

                } catch (IOException e) {
                    e.printStackTrace();
                } finally {
                    urlConnection.disconnect();
                }

            }
        });


    }


   /* void gettingImage(String icon) {
        MyApp.executorService.execute(new Runnable() {
            @Override
            public void run() {
                try {
                    int value = 0;
                    URL url = new URL(iconURL1 + icon + iconURL2);
                    //HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
                    InputStream in = url.openStream();//new BufferedInputStream(urlConnection.getInputStream());
                    Bitmap imageData = BitmapFactory.decodeStream(in);

                    handler.post(new Runnable() {
                        @Override
                        public void run() {
                            listener.gettingImageIsCompleted(imageData);
                        }
                    });
                } catch (MalformedURLException e) {
                    e.printStackTrace();

                } catch (IOException e) {
                    e.printStackTrace();
                }


            }
        });
    }*/

}
