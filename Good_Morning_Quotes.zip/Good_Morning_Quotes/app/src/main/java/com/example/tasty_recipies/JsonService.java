package com.example.tasty_recipies;

import android.util.Log;

import com.example.tasty_recipies.model.Category;
import com.example.tasty_recipies.model.Quotes;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class JsonService {

    public static ArrayList<Category> fromJSONToList(String jsonString){
        ArrayList<Category> list = new ArrayList<>(0);
        try {

            JSONObject jsonObject = new JSONObject(jsonString);

            JSONArray jsonArray = jsonObject.getJSONArray("data");

            for (int i = 0 ; i< jsonArray.length(); i++){
               Log.d("weathee_app", jsonArray.getString(i));
               int id = jsonArray.getJSONObject(i).getInt("GmCateogoryId");
               String name = jsonArray.getJSONObject(i).getString("Name");
               String thumbnail_url = jsonArray.getJSONObject(i).getString("Image");
               list.add(new Category(id,name,thumbnail_url));
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return list;
    }

    public static ArrayList<Quotes> fromJSONToList_quote(String jsonString){
        ArrayList<Quotes> list = new ArrayList<>(0);
        try {

            JSONObject jsonObject = new JSONObject(jsonString);

            JSONArray jsonArray = jsonObject.getJSONArray("Quotes");

            for (int i = 0 ; i< jsonArray.length(); i++){
                Log.d("weathee_app", jsonArray.getString(i));
                int id = jsonArray.getJSONObject(i).getInt("GmCateogoryId");
                String name = jsonArray.getJSONObject(i).getString("Quote");
                list.add(new Quotes(id,name));
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return list;
    }
}
