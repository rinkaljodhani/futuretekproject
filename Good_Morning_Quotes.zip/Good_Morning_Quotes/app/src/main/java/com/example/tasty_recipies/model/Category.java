package com.example.tasty_recipies.model;

import android.os.Parcel;
import android.os.Parcelable;

import java.io.Serializable;

public class Category implements Parcelable, Serializable {

    public int id;
    public String name;
    public String thumbnail_url;

    public Category(int id,String name ,String thumbnail_url) {
        this.id = id;
        this.name = name;
        this.thumbnail_url = thumbnail_url;
    }

    protected Category(Parcel in) {
        id = in.readInt();
        name = in.readString();
        thumbnail_url = in.readString();
    }

    public static final Creator<Category> CREATOR = new Creator<Category>() {
        @Override
        public Category createFromParcel(Parcel in) {
            return new Category(in);
        }

        @Override
        public Category[] newArray(int size) {
            return new Category[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(id);
        dest.writeString(name);
        dest.writeString(thumbnail_url);
    }
}
