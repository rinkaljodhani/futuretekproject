package com.example.tasty_recipies.activity;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.Manifest;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.example.tasty_recipies.model.Category;
import com.example.tasty_recipies.JsonService;
import com.example.tasty_recipies.MyApp;
import com.example.tasty_recipies.NetworkingService;
import com.example.tasty_recipies.R;
import com.example.tasty_recipies.adapter.CatListAdapter;
import com.tuyenmonkey.mkloader.MKLoader;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements NetworkingService.NetworkingListener, View.OnClickListener {


    RecyclerView rv_catlist;
    CatListAdapter adapter;
    ArrayList<Category> list = new ArrayList<>(0);
    TextView tv_nodata;
    LinearLayout ll_layout;
    MKLoader mkloader;
    private static final int PERMISSION_REQUEST_CODE = 1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            checkPermissions();
        }

        ((MyApp) getApplication()).networkingService.listener = this;
        findView();

        ConnectivityManager connectivityManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);

        boolean connected = (connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE).getState() == NetworkInfo.State.CONNECTED ||
                connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_WIFI).getState() == NetworkInfo.State.CONNECTED);

        if (connected) {
            ((MyApp) getApplication()).networkingService.getRecipieDetails();
        }else{
            Toast.makeText(MainActivity.this, getString(R.string.str_internet_check),Toast.LENGTH_LONG).show();
        }


    }

    @RequiresApi(api = Build.VERSION_CODES.M)
    private void checkPermissions() {
        // Check if the READ_EXTERNAL_STORAGE permission is not granted
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED ||
                // Check if the WRITE_EXTERNAL_STORAGE permission is not granted
                ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE)
                        != PackageManager.PERMISSION_GRANTED) {

            // Request permissions
            ActivityCompat.requestPermissions(
                    this,
                    new String[]{
                            Manifest.permission.READ_EXTERNAL_STORAGE,
                            Manifest.permission.WRITE_EXTERNAL_STORAGE
                    },
                    PERMISSION_REQUEST_CODE
            );
        }
    }

    @Override
    public void onRequestPermissionsResult(
            int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == PERMISSION_REQUEST_CODE) {
            // Check if all permissions are granted
            if (grantResults.length > 0 &&
                    grantResults[0] == PackageManager.PERMISSION_GRANTED &&
                    grantResults[1] == PackageManager.PERMISSION_GRANTED) {
                // Permissions are granted, you can now perform read and write operations
            } else {
                // Permissions are denied
                // Handle this case, show a message, or disable functionality that requires permissions
            }
        }
    }

    private void findView() {
        rv_catlist = findViewById(R.id.rv_catlist);
        mkloader = findViewById(R.id.mkloader);
        ll_layout = findViewById(R.id.ll_layout);
        tv_nodata = findViewById(R.id.tv_nodata);
        adapter = new CatListAdapter(this, list, false);
        rv_catlist.setAdapter(adapter);
        rv_catlist.setLayoutManager(new LinearLayoutManager(this));
    }

    @Override
    public void gettingJsonIsCompleted(String json) {
        mkloader.setVisibility(View.GONE);
        ll_layout.setVisibility(View.VISIBLE);
        list = JsonService.fromJSONToList(json);
        if(list.size()>0){
            tv_nodata.setVisibility(View.GONE);
            rv_catlist.setVisibility(View.VISIBLE);
        }else{
            rv_catlist.setVisibility(View.GONE);
            tv_nodata.setVisibility(View.VISIBLE);
        }
        adapter.list = list;
        adapter.notifyDataSetChanged();
    }

    @Override
    public void gettingImageIsCompleted(Bitmap image) {

    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {

        }
    }


    @Override
    public void onBackPressed() {
        new AlertDialog.Builder(this)
                .setMessage("Are you sure you want to exit from app?")
                .setPositiveButton("Yes", new DialogInterface.OnClickListener()
                {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        finish();
                    }

                })
                .setNegativeButton("No", null)
                .show();
    }
}