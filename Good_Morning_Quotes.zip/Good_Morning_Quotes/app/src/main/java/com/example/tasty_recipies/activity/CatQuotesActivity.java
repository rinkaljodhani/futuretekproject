package com.example.tasty_recipies.activity;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.graphics.Bitmap;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.tasty_recipies.JsonService;
import com.example.tasty_recipies.MyApp;
import com.example.tasty_recipies.NetworkingService;
import com.example.tasty_recipies.model.Quotes;
import com.example.tasty_recipies.R;
import com.example.tasty_recipies.adapter.QuoteListAdapter;
import com.tuyenmonkey.mkloader.MKLoader;

import java.util.ArrayList;

public class CatQuotesActivity extends AppCompatActivity implements NetworkingService.NetworkingListener{


    RecyclerView rv_catlist;
    QuoteListAdapter adapter;
    ArrayList<Quotes> list = new ArrayList<>(0);
    TextView tv_nodata;
    LinearLayout ll_layout;
    String name = "";
    MKLoader mkloader;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ((MyApp) getApplication()).networkingService.listener = this;


        ConnectivityManager connectivityManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);

        boolean connected = (connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE).getState() == NetworkInfo.State.CONNECTED ||
                connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_WIFI).getState() == NetworkInfo.State.CONNECTED);

        int id = getIntent().getIntExtra("id", 0);
        name = getIntent().getStringExtra("name");

        getSupportActionBar().setTitle(name);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        findView();
        if (connected) {
            ((MyApp) getApplication()).networkingService.getQuoteList(id);
        } else {
            Toast.makeText(CatQuotesActivity.this, getString(R.string.str_internet_check), Toast.LENGTH_LONG).show();
        }


    }

    private void findView() {
        rv_catlist = findViewById(R.id.rv_catlist);
        mkloader = findViewById(R.id.mkloader);
        ll_layout = findViewById(R.id.ll_layout);
        tv_nodata = findViewById(R.id.tv_nodata);
        adapter = new QuoteListAdapter(this, list, name,false);
        rv_catlist.setAdapter(adapter);
        rv_catlist.setLayoutManager(new LinearLayoutManager(this));
    }

    @Override
    public void gettingJsonIsCompleted(String json) {
        mkloader.setVisibility(View.GONE);
        ll_layout.setVisibility(View.VISIBLE);
        list = JsonService.fromJSONToList_quote(json);
        if (list.size() > 0) {
            tv_nodata.setVisibility(View.GONE);
            rv_catlist.setVisibility(View.VISIBLE);
        } else {
            rv_catlist.setVisibility(View.GONE);
            tv_nodata.setVisibility(View.VISIBLE);
        }
        adapter.list = list;
        adapter.notifyDataSetChanged();
    }

    @Override
    public void gettingImageIsCompleted(Bitmap image) {

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                onBackPressed();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }


}