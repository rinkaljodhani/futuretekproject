package com.example.tasty_recipies.adapter;

import android.content.Context;
import android.content.Intent;
import android.os.StrictMode;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.example.tasty_recipies.model.Quotes;
import com.example.tasty_recipies.R;
import com.example.tasty_recipies.activity.QuoteDetailsActivity;

import java.util.ArrayList;

public class QuoteListAdapter extends
        RecyclerView.Adapter<QuoteListAdapter.ReceipeViewHolder>{

    Context context;
    public ArrayList<Quotes> list;
    String cat_name;
    boolean flag;

    public QuoteListAdapter(Context context, ArrayList<Quotes> list, String name, boolean flag) {
        this.context = context;
        this.cat_name = name;
        this.list = list;
        this.flag = flag;
    }

    @NonNull
    @Override
    public ReceipeViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(context).inflate(R.layout.receipe_row,parent,false);
        return new ReceipeViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull ReceipeViewHolder holder, int position) {
        holder.tv_name.setText(list.get(position).name);
        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder()
                .permitAll().build();
        StrictMode.setThreadPolicy(policy);

        holder.card_layout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, QuoteDetailsActivity.class);
                intent.putExtra("quote", list.get(position).name);
                intent.putExtra("cat_name", cat_name);
                context.startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    // inner class
    public class ReceipeViewHolder extends RecyclerView.ViewHolder

    {
        ImageView iv_image;
        TextView tv_name;
        CardView card_layout;

        public ReceipeViewHolder(@NonNull View itemView) {
            super(itemView);
            iv_image =  itemView.findViewById(R.id.iv_image);
            tv_name =  itemView.findViewById(R.id.tv_name);
            card_layout =  itemView.findViewById(R.id.card_layout);
        }


    }
}
