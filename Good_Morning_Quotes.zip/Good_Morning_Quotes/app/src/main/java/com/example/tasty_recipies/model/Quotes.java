package com.example.tasty_recipies.model;

import android.os.Parcel;
import android.os.Parcelable;

import java.io.Serializable;

public class Quotes implements Parcelable, Serializable {

    public int id;
    public String name;

    public Quotes(int id, String name) {
        this.id = id;
        this.name = name;
    }

    protected Quotes(Parcel in) {
        id = in.readInt();
        name = in.readString();
    }

    public static final Creator<Quotes> CREATOR = new Creator<Quotes>() {
        @Override
        public Quotes createFromParcel(Parcel in) {
            return new Quotes(in);
        }

        @Override
        public Quotes[] newArray(int size) {
            return new Quotes[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(id);
        dest.writeString(name);
    }
}
