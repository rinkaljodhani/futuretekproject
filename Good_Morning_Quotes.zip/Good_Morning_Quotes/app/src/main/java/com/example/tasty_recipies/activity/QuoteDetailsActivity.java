package com.example.tasty_recipies.activity;

import static android.widget.FrameLayout.*;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.StrictMode;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.MediaController;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.VideoView;

import com.example.tasty_recipies.model.Category;
import com.example.tasty_recipies.R;

public class QuoteDetailsActivity extends AppCompatActivity implements View.OnClickListener {

    TextView tv_quote;
    ImageView iv_wp, iv_share, iv_copy;
    String quote = "", cat_name = "";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recipe_details);

        findView();

    }

    private void findView() {

        quote = getIntent().getStringExtra("quote");
        cat_name = getIntent().getStringExtra("cat_name");

        tv_quote = findViewById(R.id.tv_quote);
        iv_wp = findViewById(R.id.iv_wp);
        iv_share = findViewById(R.id.iv_share);
        iv_copy = findViewById(R.id.iv_copy);

        getSupportActionBar().setTitle(cat_name);

        tv_quote.setText(quote);

        iv_copy.setOnClickListener(this);
        iv_wp.setOnClickListener(this);
        iv_share.setOnClickListener(this);


    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                onBackPressed();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onClick(View v) {

        switch (v.getId()) {
            case R.id.iv_wp:
                Intent sendIntent = new Intent(Intent.ACTION_SEND);
                sendIntent.setType("text/plain");
                sendIntent.putExtra(Intent.EXTRA_TEXT, quote);
                sendIntent.setPackage("com.whatsapp");
                startActivity(sendIntent);
                break;
            case R.id.iv_copy:
                ClipboardManager clipboard = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
                ClipData clip = ClipData.newPlainText("label", quote);
                clipboard.setPrimaryClip(clip);
                Toast.makeText(QuoteDetailsActivity.this,"copied to clipboard",Toast.LENGTH_SHORT).show();
                break;
            case R.id.iv_share:
                Intent sendIntent1 = new Intent(Intent.ACTION_SEND);
                sendIntent1.setType("text/plain");
                sendIntent1.putExtra(Intent.EXTRA_TEXT, quote);
                startActivity(sendIntent1);
                break;
        }
    }


}
